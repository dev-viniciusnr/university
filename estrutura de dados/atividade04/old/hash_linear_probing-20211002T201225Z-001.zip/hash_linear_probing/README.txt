Os arquivos desta pasta podem ser compilados com:

$ g++ *.cpp

Feito isso, a execução será feita com:

$ ./a.out
