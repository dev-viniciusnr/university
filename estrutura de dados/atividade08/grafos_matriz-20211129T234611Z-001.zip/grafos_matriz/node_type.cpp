#include <iostream>
#include "node_type.h"

// std::ostream &operator<<(std::ostream &os, Vertex const &m) { 
//   return os << m.getNome();
// }
